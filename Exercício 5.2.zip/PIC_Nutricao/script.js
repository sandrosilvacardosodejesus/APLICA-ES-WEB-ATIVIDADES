// Armazenamento em memória: array de objetos JavaScript.
// Ao recarregar a página, os dados voltam aos exemplos iniciais.
let alimentos = [
  { id: 1, nome: "Maçã", categoria: "Fruta", calorias: 52, nutrientes: "Fibras, vitamina C e potássio", beneficios: "Contribui para o funcionamento intestinal." },
  { id: 2, nome: "Banana", categoria: "Fruta", calorias: 89, nutrientes: "Potássio, vitamina B6 e fibras", beneficios: "Contribui para o funcionamento muscular." },
  { id: 3, nome: "Cenoura", categoria: "Legume", calorias: 41, nutrientes: "Betacaroteno e fibras", beneficios: "Fornece precursores da vitamina A, importante para a visão." },
  { id: 4, nome: "Brócolis", categoria: "Verdura", calorias: 34, nutrientes: "Vitamina C, vitamina K e fibras", beneficios: "Fornece nutrientes importantes para a saúde óssea." }
];

const formulario = document.getElementById("formAlimento");
const lista = document.getElementById("listaAlimentos");
const busca = document.getElementById("busca");
const total = document.getElementById("total");
const vazio = document.getElementById("vazio");
const btnSalvar = document.getElementById("btnSalvar");
const btnCancelar = document.getElementById("btnCancelar");
let idEmEdicao = null;
let proximoId = 5;

function criarTexto(tag, conteudo) {
  const elemento = document.createElement(tag);
  elemento.textContent = conteudo;
  return elemento;
}

function renderizarAlimentos() {
  lista.innerHTML = "";
  const termo = busca.value.trim().toLowerCase();
  const encontrados = alimentos.filter(alimento =>
    alimento.nome.toLowerCase().includes(termo) ||
    alimento.categoria.toLowerCase().includes(termo)
  );
  total.textContent = alimentos.length;
  vazio.hidden = encontrados.length > 0;

  encontrados.forEach(alimento => {
    const card = document.createElement("article");
    card.className = "card";
    card.appendChild(criarTexto("h3", alimento.nome));
    card.appendChild(criarTexto("p", `Categoria: ${alimento.categoria}`));
    card.appendChild(criarTexto("p", `Calorias: ${alimento.calorias} kcal por 100 g`));
    card.appendChild(criarTexto("p", `Nutrientes: ${alimento.nutrientes}`));
    card.appendChild(criarTexto("p", `Benefícios: ${alimento.beneficios}`));

    const acoes = document.createElement("div");
    acoes.className = "acoes";
    const editar = criarTexto("button", "Editar");
    editar.className = "editar";
    editar.type = "button";
    editar.addEventListener("click", () => editarAlimento(alimento.id));
    const excluir = criarTexto("button", "Excluir");
    excluir.className = "excluir";
    excluir.type = "button";
    excluir.addEventListener("click", () => excluirAlimento(alimento.id));
    acoes.appendChild(editar);
    acoes.appendChild(excluir);
    card.appendChild(acoes);
    lista.appendChild(card);
  });
}

function limparEdicao() {
  idEmEdicao = null;
  formulario.reset();
  btnSalvar.textContent = "Cadastrar alimento";
  btnCancelar.hidden = true;
}

formulario.addEventListener("submit", function(evento) {
  evento.preventDefault();
  const nome = document.getElementById("nome").value.trim();
  const categoria = document.getElementById("categoria").value;
  const calorias = Number(document.getElementById("calorias").value);
  const nutrientes = document.getElementById("nutrientes").value.trim();
  const beneficios = document.getElementById("beneficios").value.trim();
  if (!nome || !nutrientes || !beneficios || !Number.isFinite(calorias) || calorias < 0) return;

  if (idEmEdicao === null) {
    alimentos.push({ id: proximoId++, nome, categoria, calorias, nutrientes, beneficios });
  } else {
    const alimento = alimentos.find(item => item.id === idEmEdicao);
    if (alimento) Object.assign(alimento, { nome, categoria, calorias, nutrientes, beneficios });
  }
  limparEdicao();
  renderizarAlimentos();
});

function editarAlimento(id) {
  const alimento = alimentos.find(item => item.id === id);
  if (!alimento) return;
  idEmEdicao = id;
  document.getElementById("nome").value = alimento.nome;
  document.getElementById("categoria").value = alimento.categoria;
  document.getElementById("calorias").value = alimento.calorias;
  document.getElementById("nutrientes").value = alimento.nutrientes;
  document.getElementById("beneficios").value = alimento.beneficios;
  btnSalvar.textContent = "Salvar alterações";
  btnCancelar.hidden = false;
  formulario.scrollIntoView({ behavior: "smooth" });
}

function excluirAlimento(id) {
  alimentos = alimentos.filter(alimento => alimento.id !== id);
  if (idEmEdicao === id) limparEdicao();
  renderizarAlimentos();
}

btnCancelar.addEventListener("click", limparEdicao);
busca.addEventListener("input", renderizarAlimentos);
renderizarAlimentos();
