// Guarda o card que foi clicado no momento
var cardAtualSelecionado = null;
var idadeTotalEmMeses = null;

// --- PARTE 1: CÁLCULO AUTOMÁTICO DE IDADE (ANOS E MESES) ---
var campoNascimento = document.getElementById('dataNascimento');
var campoIdadeAnos = document.getElementById('idadeAnos');
var campoIdadeMeses = document.getElementById('idadeMeses');

if (campoNascimento) {
  campoNascimento.addEventListener('change', function() {
    var valorData = campoNascimento.value;

    if (valorData === '') {
      if (campoIdadeAnos) campoIdadeAnos.value = '';
      if (campoIdadeMeses) campoIdadeMeses.value = '';
      idadeTotalEmMeses = null;
      atualizarAlertasVacinas();
      return;
    }

    var partes = valorData.split('-');
    var anoNasc = parseInt(partes[0], 10);
    var mesNasc = parseInt(partes[1], 10);
    var diaNasc = parseInt(partes[2], 10);

    var hoje = new Date();
    var anoHoje = hoje.getFullYear();
    var mesHoje = hoje.getMonth() + 1;
    var diaHoje = hoje.getDate();

    var anos = anoHoje - anoNasc;
    var meses = mesHoje - mesNasc;

    if (diaHoje < diaNasc) {
      meses = meses - 1;
    }

    if (meses < 0) {
      anos = anos - 1;
      meses = meses + 12;
    }

    if (anos < 0) {
      alert('Umhla wokuzalwa awukwazi ukuba ngaphezulu kunomhla wanamhlanje!');
      campoNascimento.value = '';
      if (campoIdadeAnos) campoIdadeAnos.value = '';
      if (campoIdadeMeses) campoIdadeMeses.value = '';
      idadeTotalEmMeses = null;
      atualizarAlertasVacinas();
      return;
    }

    if (campoIdadeAnos) campoIdadeAnos.value = anos + (anos === 1 ? ' unyaka' : ' iminyaka');
    if (campoIdadeMeses) campoIdadeMeses.value = meses + (meses === 1 ? ' inyanga' : ' iinyanga');

    idadeTotalEmMeses = anos * 12 + meses;
    atualizarAlertasVacinas();
  });
}


// --- PARTE 2: FUNÇÕES DE VALIDAÇÃO DO DOCUMENTO DA ÁFRICA DO SUL E CARTÃO SUS ---
function limparNumeros(texto) {
  if (!texto) return '';
  var resultado = '';
  for (var i = 0; i < texto.length; i++) {
    var caractere = texto[i];
    if (caractere >= '0' && caractere <= '9') {
      resultado = resultado + caractere;
    }
  }
  return resultado;
}

function validarDocumentoAfricaDoSul(idTexto) {
  var id = limparNumeros(idTexto);

  if (id.length !== 13) {
    return false;
  }

  var mes = parseInt(id.substring(2, 4), 10);
  var dia = parseInt(id.substring(4, 6), 10);
  if (mes < 1 || mes > 12 || dia < 1 || dia > 31) {
    return false;
  }

  if (id[10] !== '0' && id[10] !== '1') {
    return false;
  }

  var soma = 0;
  var alternar = false;
  for (var i = id.length - 1; i >= 0; i--) {
    var digito = parseInt(id[i], 10);
    if (alternar) {
      digito = digito * 2;
      if (digito > 9) {
        digito = digito - 9;
      }
    }
    soma = soma + digito;
    alternar = !alternar;
  }

  return soma % 10 === 0;
}

function validarCartaoSUS(susTexto) {
  var cns = limparNumeros(susTexto);

  if (cns.length !== 15) {
    return false;
  }

  var primeiroDigito = cns[0];
  if (
    primeiroDigito !== '1' &&
    primeiroDigito !== '2' &&
    primeiroDigito !== '7' &&
    primeiroDigito !== '8' &&
    primeiroDigito !== '9'
  ) {
    return false;
  }

  var soma = 0;
  for (var i = 0; i < 15; i++) {
    soma = soma + parseInt(cns[i], 10) * (15 - i);
  }

  return soma % 11 === 0;
}


// --- PARTE 3: ENVIO, VALIDAÇÃO E SALVAMENTO LOCAL EM JSON (COM AS VACINAS) ---
var formulario = document.getElementById('form-crianca');

if (formulario) {
  formulario.addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o recarregamento padrão da página

    // 1. Recolher os dados do formulário
    var nomeCrianca = document.getElementById('nomeCrianca').value.trim();
    var dataNascimento = document.getElementById('dataNascimento').value;
    var saId = document.getElementById('cpfCrianca').value.trim();
    var sus = document.getElementById('numeroSus').value.trim();
    var responsavel1 = document.getElementById('responsavel1').value.trim();
    var responsavel2 = document.getElementById('responsavel2').value.trim();

    var mensagemErro = document.getElementById('mensagem-cadastro');

    if (nomeCrianca === '' || dataNascimento === '' || saId === '' || sus === '' || responsavel1 === '') {
      alert('Nceda ugcwalise zonke izithuba ezinyanzelekileyo eziphawulwe ngo-*!');
      return;
    }

    // 2. Validação simples do SA ID (exige exatamente 13 dígitos numéricos e válidos)
    if (!validarDocumentoAfricaDoSul(saId)) {
      alert("Inombolo yesazisi somntwana (SA ID) ayilunganga! Kufuneka ibe namanani ali-13 asebenzayo.");
      return;
    }

    // 3. Validação do número SUS (exige 15 dígitos)
    if (!validarCartaoSUS(sus)) {
      alert("Inombolo yeSazisi sezeMpilo (SUS) ayilunganga! Kufuneka ibe namanani ali-15 asebenzayo.");
      return;
    }

    // 4. Recolher todas as vacinas e os seus estados atuais na tela
    var cards = document.querySelectorAll('.card-vacina');
    var vacinasRegistradas = [];

    for (var i = 0; i < cards.length; i++) {
      var c = cards[i];
      vacinasRegistradas.push({
        vacina: c.dataset.nomeVacina,
        dose: c.dataset.doseTexto,
        status: c.classList.contains('tomada') ? 'Ifakiwe (Aplicada)' : (c.classList.contains('atrasada') ? 'Ilibazisekile (Atrasada)' : 'Ilindile (Pendente)'),
        data_aplicacao: c.dataset.dataAplicacao || null,
        lote: c.dataset.numeroLote || null,
        unidade_aplicadora: c.dataset.unidadeAplicadora || null,
        responsavel_aplicacao: c.dataset.responsavelAplicacao || null
      });
    }

    // 5. Estruturar os dados completos da caderneta num objeto JSON
    var dadosCaderneta = {
      pais: 'UMzantsi Afrika (South Africa)',
      idioma: "xh-ZA",
      crianca: {
        nome: nomeCrianca,
        dataNascimento: dataNascimento,
        idade_anos: campoIdadeAnos ? campoIdadeAnos.value : '',
        idade_meses: campoIdadeMeses ? campoIdadeMeses.value : '',
        saId: limparNumeros(saId),
        sus: limparNumeros(sus),
        tutores: {
          tutor1: responsavel1,
          tutor2: responsavel2 || null
        }
      },
      vacinas: vacinasRegistradas,
      dataGeracao: new Date().toISOString()
    };

    // 6. Criar o ficheiro blob e disparar o download automático
    var dadosJson = JSON.stringify(dadosCaderneta, null, 2);
    var blob = new Blob([dadosJson], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    
    var linkDownload = document.createElement('a');
    linkDownload.href = url;
    linkDownload.download = 'caderneta_vacinacao_' + nomeCrianca.toLowerCase().replace(/\s+/g, '_') + '.json';
    document.body.appendChild(linkDownload);
    linkDownload.click();
    document.body.removeChild(linkDownload);
    URL.revokeObjectURL(url);

    // Exibir mensagem de sucesso em Xhosa
    if (mensagemErro) {
      mensagemErro.textContent = "Incwadi yokugonya igcinwe ngempumelelo!";
    }
  });
}


// --- PARTE 4: CARREGAR O ARQUIVO JSON E CRIAR OS CARDS ---
fetch('vacinasSUS.json')
  .then(function(resposta) {
    return resposta.json();
  })
  .then(function(dados) {
    var listaVacinas = dados.calendario_vacinacao_infantil_sus;
    var containerCards = document.getElementById('lista-vacinas');

    if (!containerCards) return;

    for (var i = 0; i < listaVacinas.length; i++) {
      var vacinaAtual = listaVacinas[i];
      var dosesSeparadas = separarDoses(vacinaAtual.idade);

      for (var j = 0; j < dosesSeparadas.length; j++) {
        criarCardNaTela(
          containerCards,
          vacinaAtual.vacina,
          dosesSeparadas[j],
          vacinaAtual.para_que_serve,
          j + 1
        );
      }
    }
  })
  .catch(function(erro) {
    console.log('Impazamo ekulayisheni i-vacinasSUS.json:', erro);
  });

function separarDoses(texto) {
  if (texto.indexOf(';') !== -1) {
    return [texto];
  }
  var textoComVirgulas = texto.replace(' e ', ', ');
  return textoComVirgulas.split(', ');
}

function extrairMesesRecomendados(textoIdade) {
  var texto = textoIdade.toLowerCase();
  if (texto.indexOf('ao nascer') !== -1 || texto.indexOf('ekuzalweni') !== -1) {
    return 0;
  }
  var matchAnos = texto.match(/(\d+)\s*(?:ano|anos|iminyaka)/);
  if (matchAnos) {
    return parseInt(matchAnos[1], 10) * 12;
  }
  var matchMeses = texto.match(/(\d+)\s*(?:mês|meses|iinyanga|inyanga)/);
  if (matchMeses) {
    return parseInt(matchMeses[1], 10);
  }
  return 0;
}

function criarCardNaTela(container, nomeVacina, idadeDose, descricao, numeroDose) {
  var card = document.createElement('div');
  card.className = 'card-vacina';
  card.dataset.nomeVacina = nomeVacina;
  card.dataset.doseTexto = 'Idosi ' + numeroDose + ' - ' + idadeDose;
  card.dataset.mesesRecomendados = extrairMesesRecomendados(idadeDose);

  card.innerHTML =
    '<span class="etiqueta-dose">Idosi ' + numeroDose + '</span>' +
    '<h3>' + nomeVacina + '</h3>' +
    '<p><strong>Ixesha:</strong> ' + idadeDose + '</p>' +
    '<p class="status-texto">Imeko: Ilindile</p>' +
    '<div class="detalhes-aplicacao-card escondido"></div>';

  card.addEventListener('click', function() {
    abrirJanela(card, nomeVacina, numeroDose, idadeDose, descricao);
  });

  container.appendChild(card);
}


// --- MISSÃO 3: ALERTAS DE VACINAS ATRASADAS ---
function atualizarAlertasVacinas() {
  var cards = document.querySelectorAll('.card-vacina');
  for (var i = 0; i < cards.length; i++) {
    var card = cards[i];
    var textoStatus = card.querySelector('.status-texto');
    var mesesRec = parseInt(card.dataset.mesesRecomendados, 10);

    if (card.classList.contains('tomada')) {
      card.classList.remove('atrasada');
      continue;
    }

    if (idadeTotalEmMeses !== null && idadeTotalEmMeses > mesesRec) {
      card.classList.add('atrasada');
      if (textoStatus) textoStatus.textContent = 'Imeko: Ilibazisekile (Atrasada) ⚠️';
    } else {
      card.classList.remove('atrasada');
      if (textoStatus) textoStatus.textContent = 'Imeko: Ilindile';
    }
  }
}


// --- PARTE 5: CONTROLE DA JANELA (MODAL) ---
var janela = document.getElementById('janela-detalhes');
var checkTomada = document.getElementById('check-tomada');
var camposAplicacao = document.getElementById('campos-aplicacao');

var inputDataAplicacao = document.getElementById('dataAplicacao');
var inputNumeroLote = document.getElementById('numeroLote');
var inputUnidadeAplicadora = document.getElementById('unidadeAplicadora');
var inputResponsavelAplicacao = document.getElementById('responsavelAplicacao');

var btnConfirmar = document.getElementById('btn-confirmar');
var btnFechar = document.getElementById('btn-fechar');

if (checkTomada) {
  checkTomada.addEventListener('change', function() {
    if (checkTomada.checked === true) {
      if (camposAplicacao) camposAplicacao.classList.remove('escondido');
    } else {
      if (camposAplicacao) camposAplicacao.classList.add('escondido');
    }
  });
}

function formatarDataBrasil(dataISO) {
  if (!dataISO) return '';
  var partes = dataISO.split('-');
  return partes[2] + '/' + partes[1] + '/' + partes[0];
}

function abrirJanela(cardClicado, nome, numDose, idade, descricao) {
  cardAtualSelecionado = cardClicado;

  var elTitulo = document.getElementById('janela-titulo');
  var elDose = document.getElementById('janela-dose');
  var elIdade = document.getElementById('janela-idade');
  var elDesc = document.getElementById('janela-descricao');

  if (elTitulo) elTitulo.textContent = nome;
  if (elDose) elDose.textContent = 'Idosi ' + numDose;
  if (elIdade) elIdade.textContent = idade;
  if (elDesc) elDesc.textContent = descricao;

  if (cardClicado.classList.contains('tomada')) {
    if (checkTomada) checkTomada.checked = true;
    if (camposAplicacao) camposAplicacao.classList.remove('escondido');
    if (inputDataAplicacao) inputDataAplicacao.value = cardClicado.dataset.dataAplicacao || '';
    if (inputNumeroLote) inputNumeroLote.value = cardClicado.dataset.numeroLote || '';
    if (inputUnidadeAplicadora) inputUnidadeAplicadora.value = cardClicado.dataset.unidadeAplicadora || '';
    if (inputResponsavelAplicacao) inputResponsavelAplicacao.value = cardClicado.dataset.responsavelAplicacao || '';
  } else {
    if (checkTomada) checkTomada.checked = false;
    if (camposAplicacao) camposAplicacao.classList.add('escondido');
    if (inputDataAplicacao) inputDataAplicacao.value = '';
    if (inputNumeroLote) inputNumeroLote.value = '';
    if (inputUnidadeAplicadora) inputUnidadeAplicadora.value = '';
    if (inputResponsavelAplicacao) inputResponsavelAplicacao.value = '';
  }

  if (janela) janela.classList.remove('escondido');
}

if (btnConfirmar) {
  btnConfirmar.addEventListener('click', function() {
    if (cardAtualSelecionado !== null) {
      var textoStatus = cardAtualSelecionado.querySelector('.status-texto');
      var caixaDetalhesCard = cardAtualSelecionado.querySelector('.detalhes-aplicacao-card');

      if (checkTomada && checkTomada.checked === true) {
        var dataApl = inputDataAplicacao ? inputDataAplicacao.value : '';
        var lote = inputNumeroLote ? inputNumeroLote.value : '';
        var unidade = inputUnidadeAplicadora ? inputUnidadeAplicadora.value : '';
        var responsavel = inputResponsavelAplicacao ? inputResponsavelAplicacao.value : '';

        if (dataApl === '' || lote === '' || unidade === '' || responsavel === '') {
          alert('Gcwalisa umhla wokugonya, inombolo yebhetshi, iziko lezempilo kunye nomgonyi!');
          return;
        }

        cardAtualSelecionado.dataset.dataAplicacao = dataApl;
        cardAtualSelecionado.dataset.numeroLote = lote;
        cardAtualSelecionado.dataset.unidadeAplicadora = unidade;
        cardAtualSelecionado.dataset.responsavelAplicacao = responsavel;

        cardAtualSelecionado.classList.remove('atrasada');
        cardAtualSelecionado.classList.add('tomada');
        if (textoStatus) textoStatus.textContent = 'Imeko: Ifakiwe ✓';

        if (caixaDetalhesCard) {
          caixaDetalhesCard.innerHTML =
            '<strong>Umhla:</strong> ' + formatarDataBrasil(dataApl) + '<br>' +
            '<strong>Ibhetshi:</strong> ' + lote + '<br>' +
            '<strong>Iziko:</strong> ' + unidade + '<br>' +
            '<strong>Umgonyi:</strong> ' + responsavel;
          caixaDetalhesCard.classList.remove('escondido');
        }
      } else {
        cardAtualSelecionado.classList.remove('tomada');
        if (caixaDetalhesCard) {
          caixaDetalhesCard.innerHTML = '';
          caixaDetalhesCard.classList.add('escondido');
        }
        delete cardAtualSelecionado.dataset.dataAplicacao;
        delete cardAtualSelecionado.dataset.numeroLote;
        delete cardAtualSelecionado.dataset.unidadeAplicadora;
        delete cardAtualSelecionado.dataset.responsavelAplicacao;
        atualizarAlertasVacinas();
      }
    }
    if (janela) janela.classList.add('escondido');
  });
}

if (btnFechar) {
  btnFechar.addEventListener('click', function() {
    if (janela) janela.classList.add('escondido');
  });
}