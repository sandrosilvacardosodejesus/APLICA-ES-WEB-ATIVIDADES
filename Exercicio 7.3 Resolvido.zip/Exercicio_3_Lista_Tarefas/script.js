// Array inicial de tarefas
const tarefas = ["Estudar JavaScript", "Fazer os exercícios", "Comprar café", "Revisar o código"];

function renderizarTarefas() {
  const listaEl = document.getElementById("listaTarefas");
  listaEl.innerHTML = "";

  tarefas.forEach(function(tarefa) {
    const li = document.createElement("li");
    li.textContent = tarefa;
    listaEl.appendChild(li);
  });
}

renderizarTarefas();
