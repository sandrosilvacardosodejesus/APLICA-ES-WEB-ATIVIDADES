let produtos = [];

async function carregarProdutos() {
  try {
    const resposta = await fetch('produtos.json');
    if (!resposta.ok) throw new Error('Erro ao carregar produtos');
    const dados = await resposta.json();
    if (!Array.isArray(dados)) throw new Error('JSON deve conter uma lista');
    produtos = dados;
    renderizar(produtos);
  } catch (erro) {
    console.error(erro);
    document.getElementById('gradeProdutos').textContent = 'Erro ao carregar os produtos.';
  }
}

function renderizar(lista) {
  const container = document.getElementById('gradeProdutos');
  container.innerHTML = '';
  if (lista.length === 0) {
    container.textContent = 'Nenhum produto encontrado.';
    return;
  }
  lista.forEach(produto => {
    const card = document.createElement('div');
    card.className = 'card-produto';
    const nome = document.createElement('h3');
    nome.textContent = produto.nome;
    const categoria = document.createElement('p');
    categoria.textContent = 'Categoria: ' + produto.categoria;
    const preco = document.createElement('p');
    preco.className = 'preco';
    preco.textContent = 'R$ ' + Number(produto.preco).toFixed(2);
    card.appendChild(nome);
    card.appendChild(categoria);
    card.appendChild(preco);
    container.appendChild(card);
  });
}

function filtrarProdutos() {
  const texto = document.getElementById('filtroTexto').value.toLowerCase();
  const categoria = document.getElementById('filtroCategoria').value;
  const produtosFiltrados = produtos.filter(produto => {
    const bateuNome = produto.nome.toLowerCase().includes(texto);
    const bateuCategoria = categoria === 'todas' || produto.categoria === categoria;
    return bateuNome && bateuCategoria;
  });
  renderizar(produtosFiltrados);
}

carregarProdutos();
