// Dados carregados de alimentos.json; alterações podem ser exportadas para um novo JSON.
let alimentos = [];

const formulario = document.getElementById("formAlimento");
const lista = document.getElementById("listaAlimentos");
const busca = document.getElementById("busca");
const total = document.getElementById("total");
const vazio = document.getElementById("vazio");
const btnSalvar = document.getElementById("btnSalvar");
const btnCancelar = document.getElementById("btnCancelar");
let idEmEdicao = null;
let proximoId = 1;
const statusArquivo = document.getElementById("statusArquivo");
const entradaJSON = document.getElementById("entradaJSON");

function criarTexto(tag, conteudo) {
  const elemento = document.createElement(tag);
  elemento.textContent = conteudo;
  return elemento;
}

function renderizarAlimentos() {
  lista.innerHTML = "";
  const termo = busca.value.trim().toLowerCase();
  const encontrados = alimentos.filter(alimento =>
    alimento.nome.toLowerCase().includes(termo) ||
    alimento.categoria.toLowerCase().includes(termo)
  );
  total.textContent = alimentos.length;
  vazio.hidden = encontrados.length > 0;

  encontrados.forEach(alimento => {
    const card = document.createElement("article");
    card.className = "card";
    card.appendChild(criarTexto("h3", alimento.nome));
    card.appendChild(criarTexto("p", `Categoria: ${alimento.categoria}`));
    card.appendChild(criarTexto("p", `Calorias: ${alimento.calorias} kcal por 100 g`));
    card.appendChild(criarTexto("p", `Nutrientes: ${alimento.nutrientes}`));
    card.appendChild(criarTexto("p", `Benefícios: ${alimento.beneficios}`));

    const acoes = document.createElement("div");
    acoes.className = "acoes";
    const editar = criarTexto("button", "Editar");
    editar.className = "editar";
    editar.type = "button";
    editar.addEventListener("click", () => editarAlimento(alimento.id));
    const excluir = criarTexto("button", "Excluir");
    excluir.className = "excluir";
    excluir.type = "button";
    excluir.addEventListener("click", () => excluirAlimento(alimento.id));
    acoes.appendChild(editar);
    acoes.appendChild(excluir);
    card.appendChild(acoes);
    lista.appendChild(card);
  });
}

function limparEdicao() {
  idEmEdicao = null;
  formulario.reset();
  btnSalvar.textContent = "Cadastrar alimento";
  btnCancelar.hidden = true;
}

formulario.addEventListener("submit", function(evento) {
  evento.preventDefault();
  const nome = document.getElementById("nome").value.trim();
  const categoria = document.getElementById("categoria").value;
  const calorias = Number(document.getElementById("calorias").value);
  const nutrientes = document.getElementById("nutrientes").value.trim();
  const beneficios = document.getElementById("beneficios").value.trim();
  if (!nome || !nutrientes || !beneficios || !Number.isFinite(calorias) || calorias < 0) return;

  if (idEmEdicao === null) {
    alimentos.push({ id: proximoId++, nome, categoria, calorias, nutrientes, beneficios });
  } else {
    const alimento = alimentos.find(item => item.id === idEmEdicao);
    if (alimento) Object.assign(alimento, { nome, categoria, calorias, nutrientes, beneficios });
  }
  limparEdicao();
  renderizarAlimentos();
});

function editarAlimento(id) {
  const alimento = alimentos.find(item => item.id === id);
  if (!alimento) return;
  idEmEdicao = id;
  document.getElementById("nome").value = alimento.nome;
  document.getElementById("categoria").value = alimento.categoria;
  document.getElementById("calorias").value = alimento.calorias;
  document.getElementById("nutrientes").value = alimento.nutrientes;
  document.getElementById("beneficios").value = alimento.beneficios;
  btnSalvar.textContent = "Salvar alterações";
  btnCancelar.hidden = false;
  formulario.scrollIntoView({ behavior: "smooth" });
}

function excluirAlimento(id) {
  alimentos = alimentos.filter(alimento => alimento.id !== id);
  if (idEmEdicao === id) limparEdicao();
  renderizarAlimentos();
}

btnCancelar.addEventListener("click", limparEdicao);
busca.addEventListener("input", renderizarAlimentos);

// Confere se o arquivo JSON contém uma lista válida de objetos de alimentos.
function validarAlimentos(dados) {
  if (!Array.isArray(dados) || !dados.every(item =>
    item && typeof item === "object" &&
    Number.isInteger(item.id) && item.id > 0 &&
    typeof item.nome === "string" && item.nome.trim() &&
    ["Fruta", "Legume", "Verdura"].includes(item.categoria) &&
    typeof item.calorias === "number" && Number.isFinite(item.calorias) && item.calorias >= 0 &&
    typeof item.nutrientes === "string" && typeof item.beneficios === "string"
  )) throw new Error("O JSON precisa conter uma lista válida de alimentos.");
  if (new Set(dados.map(item => item.id)).size !== dados.length) {
    throw new Error("Existem IDs repetidos no arquivo JSON.");
  }
  return dados;
}

function carregarDados(dados) {
  alimentos = validarAlimentos(dados);
  proximoId = Math.max(0, ...alimentos.map(item => item.id)) + 1;
  limparEdicao();
  renderizarAlimentos();
}

// Lê o arquivo inicial quando a página é aberta via servidor local.
async function carregarJSONInicial() {
  try {
    const resposta = await fetch("alimentos.json");
    if (!resposta.ok) throw new Error("Não foi possível acessar alimentos.json");
    carregarDados(await resposta.json());
    statusArquivo.textContent = "Dados iniciais carregados de alimentos.json.";
  } catch (erro) {
    statusArquivo.textContent = "Não foi possível carregar alimentos.json. Abra com Live Server ou importe o arquivo manualmente.";
  }
}

// Gera um arquivo JSON com os dados atuais, incluindo alterações do usuário.
document.getElementById("btnExportar").addEventListener("click", () => {
  const conteudo = JSON.stringify(alimentos, null, 2);
  const arquivo = new Blob([conteudo], { type: "application/json" });
  const url = URL.createObjectURL(arquivo);
  const link = document.createElement("a");
  link.href = url;
  link.download = "alimentos.json";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  statusArquivo.textContent = "Arquivo alimentos.json exportado. Guarde-o para importar depois.";
});

// Importa um JSON previamente salvo e substitui os dados atuais.
entradaJSON.addEventListener("change", async () => {
  const arquivo = entradaJSON.files[0];
  if (!arquivo) return;
  try {
    const dados = JSON.parse(await arquivo.text());
    carregarDados(dados);
    statusArquivo.textContent = `Arquivo ${arquivo.name} importado com sucesso.`;
  } catch (erro) {
    statusArquivo.textContent = `Erro ao importar: ${erro.message}`;
  }
  entradaJSON.value = "";
});

carregarJSONInicial();
