function atualizarPerfil() {
    // 1. Declarar as três variáveis
    const nome = "Sandro";
    const idade = 30;
    const bio = "Estudante de Análise e Desenvolvimento de Sistemas (ADS), gosto de infraestrutura de TI.";

    // 2. Atualizar os elementos HTML utilizando o DOM
    document.getElementById("nome").textContent = nome;
    document.getElementById("idade").textContent = "Idade: " + idade;
    document.getElementById("biografia").textContent = bio;
}
