// Arrays paralelos: cada índice corresponde ao mesmo alimento.
const nomes = ["Maçã", "Banana", "Cenoura", "Brócolis", "Laranja", "Abobrinha"];
const calorias = ["52 kcal", "89 kcal", "41 kcal", "34 kcal", "47 kcal", "17 kcal"];
const nutrientes = [
  "Fibras, vitamina C e potássio",
  "Potássio, vitamina B6 e fibras",
  "Betacaroteno, fibras e potássio",
  "Vitamina C, vitamina K e fibras",
  "Vitamina C, folato e fibras",
  "Água, potássio e vitamina C"
];
const beneficios = [
  "Contribui para o funcionamento intestinal e fornece antioxidantes.",
  "Fornece energia e contribui para o funcionamento muscular.",
  "Contribui para a saúde da visão e para o funcionamento intestinal.",
  "Contribui para a saúde óssea e para o funcionamento do sistema imunológico.",
  "Auxilia na absorção de ferro e contribui para a saúde imunológica.",
  "Ajuda na hidratação e contribui para uma alimentação variada."
];

const selectAlimentos = document.getElementById("selectAlimentos");
const btnDetalhes = document.getElementById("btnDetalhes");
const divNome = document.getElementById("divNome");
const divCalorias = document.getElementById("divCalorias");
const divNutrientes = document.getElementById("divNutrientes");
const divBeneficios = document.getElementById("divBeneficios");

btnDetalhes.addEventListener("click", function () {
  const index = selectAlimentos.value;
  if (index !== "") {
    divNome.textContent = nomes[index];
    divCalorias.textContent = calorias[index];
    divNutrientes.textContent = nutrientes[index];
    divBeneficios.textContent = beneficios[index];
  }
});
